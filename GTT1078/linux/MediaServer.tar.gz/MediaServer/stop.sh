#!/bin/bash



echo "Stopping ..."
ps -ef |grep  startup.sh | grep -v grep | awk '{print $2}' | xargs kill
ps -ef |grep  CarEyeMediaServer | grep -v grep | awk '{print $2}' | xargs kill -9
