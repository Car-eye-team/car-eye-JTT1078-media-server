#!/bin/bash

echo "start service"
nohup  /home/CarEye/MediaServer/startup.sh >/home/CarEye/MediaServer/check.log 2>&1&

