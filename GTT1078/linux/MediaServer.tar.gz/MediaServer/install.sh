#!/bin/sh

echo "create file system and copy file"



PROJ_PATH=$(cd `dirname $0`; pwd)

if [ ! -d "/home/CarEye" ]; then
        mkdir -p /home/CarEye
fi

if [ ! -d "/home/CarEye/MediaServer" ]; then
        mkdir -p /home/CarEye/MediaServer
fi

rm -rf /home/CarEye/MediaServer/*

cd $PROJ_PATH
cp Configure.xml /home/CarEye/MediaServer
cp CarEyeMediaServer /home/CarEye/MediaServer
cp startup.sh  /home/CarEye/MediaServer


echo "install libs"
cd $PROJ_PATH
./install_lib.sh
echo "install service"
chmod 777 start.sh
chmod 777 stop.sh
chmod 777 vedio.service
cp -f start.sh /home/CarEye/MediaServer
cp -f stop.sh /home/CarEye/MediaServer
cp -f vedio.service /etc/systemd/system
systemctl daemon-reload
systemctl enable vedio
systemctl start vedio.service







