#! /bin/sh




sec=10
filename=$(date +%y%m%d%H%M%S).log
while true
do
  Thread=`ps -ef | grep CarEyeMediaServer | grep -v "grep"`
  echo $Thread
  count=`ps -ef | grep CarEyeMediaServer | grep -v "grep" | wc -l`
  echo $count
  if [ $count -gt 0 ]; then
    echo sleep $sec second , the CarEyeMediaServer thread is still alive
    sleep $sec
  else
    echo restart vedio server
    cd /home/CarEye/MediaServer/
    mkdir -p log
    nohup ./CarEyeMediaServer>log/$filename 2>&1&
    sleep $sec
  fi
done



