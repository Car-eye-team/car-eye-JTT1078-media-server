#!/bin/sh

# project path
PROJ_PATH=$(cd `dirname $0`; pwd)

# install ffmpeg libs
if [ ! -d "/usr/lib/ffmepg" ]; then
	mkdir -p /usr/lib/ffmpeg
fi

rm -rf /usr/lib/ffmpeg/*
cp $PROJ_PATH/Libs/ffmpeg/* /usr/lib/ffmpeg/

cd /usr/lib/ffmpeg
ln -s ./libavcodec.so.57.107.100 ./libavcodec.so
ln -s ./libavcodec.so.57.107.100 ./libavcodec.so.57
ln -s ./libavdevice.so.57.10.100 ./libavdevice.so
ln -s ./libavdevice.so.57.10.100 ./libavdevice.so.57
ln -s ./libavfilter.so.6.107.100 ./libavfilter.so
ln -s ./libavfilter.so.6.107.100 ./libavfilter.so.6
ln -s ./libavformat.so.57.83.100 ./libavformat.so
ln -s ./libavformat.so.57.83.100 ./libavformat.so.57
ln -s ./libavutil.so.55.78.100 ./libavutil.so
ln -s ./libavutil.so.55.78.100 ./libavutil.so.55
ln -s ./libswresample.so.2.9.100 ./libswresample.so
ln -s ./libswresample.so.2.9.100 ./libswresample.so.2
ln -s ./libswscale.so.4.8.100 ./libswscale.so
ln -s ./libswscale.so.4.8.100 ./libswscale.so.4

# Update system libs
cp -f $PROJ_PATH/Libs/libstdc++.so.6.0.24 /usr/lib64/
ln -snf /usr/lib64/libstdc++.so.6.0.24 /lib64/libstdc++.so.6





# libav libXv



cp -f $PROJ_PATH/Libs/libva/*  /usr/lib64
cp -f $PROJ_PATH/Libs/libXv/*  /usr/lib64 

cd /usr/lib64/

ln -s ./libva-drm.so.1.4000.0 ./libva-drm.so
ln -s ./libva-drm.so.1.4000.0 ./libva-drm.so.1
ln -s ./ibva-egl.so.1.4000.0  ./ibva-egl.so
ln -s ./libva-egl.so.1.4000.0  ./ibva-egl.so.1
ln -s ./libva-glx.so.1.4000.0 ./libva-glx.so
ln -s ./libva-glx.so.1.4000.0 ./libva-glx.so.1
ln -s ./libva.so.1.4000.0   ./libva.so
ln -s ./libva.so.1.4000.0   ./libva.so.1
ln -s ./libva-x11.so.1.4000.0  ./libva-x11.so
ln -s ./libva-x11.so.1.4000.0  ./libva-x11.so.1
ln -s ./libva-wayland.so.1.4000.0  ./libva-wayland.so
ln -s ./libva-wayland.so.1.4000.0   ./libva-wayland.so.1
ln -s ./libva-tpi.so.1.4000.0    ./libva-tpi.so.1
ln -s ./libva-tpi.so.1.4000.0  ./libva-tpi.so
ln -s ./libXv.so.1.0.0   ./libXv.so
ln -s ./libXv.so.1.0.0   ./libXv.so.1
ln -s ./libXvMCW.so.1.0.0 ./libXvMCW.so
ln -s ./libXvMCW.so.1.0.0 ./libXvMCW.so.1
ln -s ./libXvMC.so.1.0.0  ./libXvMC.so
ln -s ./libXvMC.so.1.0.0 ./libXvMC.so.1
ln -s ./libX11.so.6.3.0  ./libX11.so
ln -s ./libX11.so.6.3.0  ./libX11.so.6
ln -s ./libX11-xcb.so.1.0.0 ./libX11-xcb.so
ln -s ./libX11-xcb.so.1.0.0 ./libX11-xcb.so.1
ln -s ./libXext.so.6.4.0 ./libXext.so
ln -s ./libXext.so.6.4.0  ./libXext.so.6
ln -s ./libxcb-xfixes.so.0.0.0 ./libxcb-xfixes.so
ln -s ./libxcb-xfixes.so.0.0.0  ./libxcb-xfixes.so.0
ln -s ./libXfixes.so.3.1.0 ./libXfixes.so
ln -s ./libXfixes.so.3.1.0 ./libXfixes.so.3

# install dependent libraries
#yum -y install libXv
#yum -y install libva
