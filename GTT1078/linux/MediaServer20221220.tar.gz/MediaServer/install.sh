#!/bin/sh

echo "create file system and copy file"



PROJ_PATH=$(cd `dirname $0`; pwd)

if [ ! -d "/home/CarEye" ]; then
        mkdir -p /home/CarEye
fi

if [ ! -d "/home/CarEye/MediaServer" ]; then
        mkdir -p /home/CarEye/MediaServer
fi

rm -rf /home/CarEye/MediaServer/*

cd $PROJ_PATH
cp Configure.xml /home/CarEye/MediaServer
cp CarEyeMediaServer /home/CarEye/MediaServer
cp startup.sh  /home/CarEye/MediaServer


echo "install libs"
cd $PROJ_PATH
./install_lib.sh
echo "install service"
cp -f vedio_check /etc/init.d/
chmod 777  /etc/init.d/vedio_check
echo "start service"
service vedio_check start






