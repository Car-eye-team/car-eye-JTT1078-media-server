

sec=10

while true
do
  Thread=`ps -ef | grep CarEyeMediaServer | grep -v "grep"`
  echo $Thread
  count=`ps -ef | grep CarEyeMediaServer | grep -v "grep" | wc -l`
  echo $count
  if [ $count -gt 0 ]; then
    echo sleep $sec second , the CarEyeMediaServer thread is still alive
    break;
  else
    echo restart vedio server
    cd /usr/local/vedio
    nohup ./CarEyeMediaServer>log.file 2>&1&
    sleep $sec
  fi
done




