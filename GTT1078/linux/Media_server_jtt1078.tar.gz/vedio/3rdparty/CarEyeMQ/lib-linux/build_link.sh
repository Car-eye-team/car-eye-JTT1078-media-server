#!/bin/sh
rm -f ./libactivemq-cpp.so
rm -f ./libactivemq-cpp.so.19
rm -f ./libapr-1.so
rm -f ./libapr-1.so.0
rm -f ./libapriconv-1.so
rm -f ./libapriconv-1.so.0
rm -f ./libaprutil-1.so
rm -f ./libaprutil-1.so.0
ln -s ./libactivemq-cpp.so.19.0.4 ./libactivemq-cpp.so
ln -s ./libactivemq-cpp.so.19.0.4 ./libactivemq-cpp.so.19
ln -s ./libapr-1.so.0.6.5 ./libapr-1.so
ln -s ./libapr-1.so.0.6.5 ./libapr-1.so.0
ln -s ./libapriconv-1.so.0.2.2 ./libapriconv-1.so
ln -s ./libapriconv-1.so.0.2.2 ./libapriconv-1.so.0
ln -s ./libaprutil-1.so.0.6.1 ./libaprutil-1.so
ln -s ./libaprutil-1.so.0.6.1 ./libaprutil-1.so.0
