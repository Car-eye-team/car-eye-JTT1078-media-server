
sec=10

while true
do
    /usr/local/vedio/vedio.sh
    sleep $sec
done


